import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useBeforeUnload, useLocation, useNavigate, useBlocker } from "react-router-dom";
import { getAllBookTitles, saveSession } from "../db";
import { formatClock, formatAddedDuration } from "../utils/format";
import { NavyButton, GoldButton, OutlineButton } from "../components/Buttons";
import { ConfirmDialog } from "../components/ConfirmDialog";

type Status = "idle" | "running" | "paused";
type Mode = "timer" | "manual";

const DISCARD_CONFIRM_THRESHOLD_SECONDS = 30;

function todayDateString(): string {
  const now = new Date();
  const offset = now.getTimezoneOffset();
  return new Date(now.getTime() - offset * 60000).toISOString().slice(0, 10);
}

export function Timer() {
  const navigate = useNavigate();
  const location = useLocation();
  const prefillTitle = (location.state as { bookTitle?: string } | null)?.bookTitle ?? "";

  const [mode, setMode] = useState<Mode>("timer");
  const [title, setTitle] = useState(prefillTitle);
  const [status, setStatus] = useState<Status>("idle");
  const [elapsed, setElapsed] = useState(0);
  const [allTitles, setAllTitles] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [pendingExit, setPendingExit] = useState<null | (() => void)>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [manualDate, setManualDate] = useState(todayDateString);
  const [manualMinutes, setManualMinutes] = useState("");
  const [manualError, setManualError] = useState<string | null>(null);

  const startTimeRef = useRef<number | null>(null);
  const accumulatedRef = useRef(0);
  const sessionStartedAtRef = useRef<string | null>(null);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    getAllBookTitles().then(setAllTitles);
  }, []);

  useEffect(() => {
    if (status === "running") {
      intervalRef.current = window.setInterval(() => {
        const start = startTimeRef.current ?? Date.now();
        setElapsed(accumulatedRef.current + (Date.now() - start) / 1000);
      }, 200);
      return () => {
        if (intervalRef.current) window.clearInterval(intervalRef.current);
      };
    }
  }, [status]);

  const hasUnsavedProgress = status !== "idle" && elapsed >= DISCARD_CONFIRM_THRESHOLD_SECONDS;

  useBeforeUnload(
    useCallback(
      (e: BeforeUnloadEvent) => {
        if (hasUnsavedProgress) {
          e.preventDefault();
        }
      },
      [hasUnsavedProgress],
    ),
  );

  const blocker = useBlocker(
    ({ currentLocation, nextLocation }) =>
      hasUnsavedProgress && currentLocation.pathname !== nextLocation.pathname,
  );

  useEffect(() => {
    if (blocker.state === "blocked") {
      setPendingExit(() => () => blocker.proceed?.());
    }
  }, [blocker]);

  function handleStart() {
    sessionStartedAtRef.current = new Date().toISOString();
    startTimeRef.current = Date.now();
    accumulatedRef.current = 0;
    setElapsed(0);
    setStatus("running");
  }

  function handlePause() {
    if (startTimeRef.current) {
      accumulatedRef.current += (Date.now() - startTimeRef.current) / 1000;
    }
    startTimeRef.current = null;
    setStatus("paused");
  }

  function handleResume() {
    startTimeRef.current = Date.now();
    setStatus("running");
  }

  function computeFinalSeconds() {
    const running = status === "running" && startTimeRef.current;
    const extra = running ? (Date.now() - (startTimeRef.current as number)) / 1000 : 0;
    return Math.round(accumulatedRef.current + extra);
  }

  async function handleStopAndSave() {
    const trimmedTitle = title.trim();
    if (!trimmedTitle) {
      setValidationError("Add a book title before saving.");
      return;
    }
    const durationSeconds = computeFinalSeconds();
    const startedAt = sessionStartedAtRef.current ?? new Date().toISOString();
    const endedAt = new Date().toISOString();

    if (durationSeconds < 1) {
      resetTimer();
      navigate("/");
      return;
    }

    await saveSession({ bookTitle: trimmedTitle, durationSeconds, startedAt, endedAt });

    navigate("/", {
      state: {
        toast: `Nice, ${formatAddedDuration(durationSeconds)} added to ${trimmedTitle}.`,
      },
    });
  }

  async function handleSaveManual() {
    const trimmedTitle = title.trim();
    if (!trimmedTitle) {
      setValidationError("Add a book title before saving.");
      return;
    }
    if (!manualDate || manualDate > todayDateString()) {
      setManualError("Pick a date that isn't in the future.");
      return;
    }
    const minutes = Number(manualMinutes);
    if (!Number.isInteger(minutes) || minutes < 1) {
      setManualError("Enter a whole number of minutes, 1 or more.");
      return;
    }

    const startedAt = new Date(`${manualDate}T12:00:00`).toISOString();
    const durationSeconds = minutes * 60;

    await saveSession({ bookTitle: trimmedTitle, durationSeconds, startedAt, endedAt: startedAt });

    navigate("/", {
      state: {
        toast: `Nice, ${formatAddedDuration(durationSeconds)} added to ${trimmedTitle}.`,
      },
    });
  }

  function resetTimer() {
    accumulatedRef.current = 0;
    startTimeRef.current = null;
    sessionStartedAtRef.current = null;
    setElapsed(0);
    setStatus("idle");
  }

  function handleExitAttempt() {
    if (hasUnsavedProgress) {
      setPendingExit(() => () => navigate("/"));
    } else {
      navigate("/");
    }
  }

  function confirmExit() {
    const exit = pendingExit;
    setPendingExit(null);
    resetTimer();
    exit?.();
  }

  function cancelExit() {
    setPendingExit(null);
    if (blocker.state === "blocked") blocker.reset?.();
  }

  const suggestions = useMemo(() => {
    const q = title.trim().toLowerCase();
    if (!q) return [];
    return allTitles.filter((t) => t.toLowerCase().includes(q) && t.toLowerCase() !== q).slice(0, 5);
  }, [title, allTitles]);

  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-5 pt-6 sm:pt-10">
      <div className="flex w-full items-center justify-between">
        <button
          onClick={handleExitAttempt}
          aria-label="Close timer"
          className="flex h-10 w-10 items-center justify-center rounded-full text-text-body transition hover:bg-tint-blue"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
        <h1 className="font-heading font-bold text-text-heading">Reading Timer</h1>
        <div className="w-10" />
      </div>

      <div className="relative mt-8 w-full">
        <label htmlFor="book-title" className="mb-1.5 block text-sm font-medium text-text-body">
          What are you reading?
        </label>
        <input
          id="book-title"
          type="text"
          value={title}
          disabled={status !== "idle"}
          onChange={(e) => {
            setTitle(e.target.value);
            setValidationError(null);
            setShowSuggestions(true);
          }}
          onFocus={() => setShowSuggestions(true)}
          onBlur={() => setTimeout(() => setShowSuggestions(false), 120)}
          placeholder="Book title"
          className="w-full rounded-[16px] border-2 border-border-subtle bg-bg-card px-4 py-3.5 font-heading text-lg font-semibold text-text-heading outline-none transition focus:border-primary-navy disabled:opacity-70"
        />
        {validationError && <p className="mt-1.5 text-sm text-danger">{validationError}</p>}
        {showSuggestions && suggestions.length > 0 && (
          <ul className="absolute z-10 mt-1.5 w-full overflow-hidden rounded-[16px] border border-border-subtle bg-bg-card shadow-lg">
            {suggestions.map((s) => (
              <li key={s}>
                <button
                  className="w-full px-4 py-2.5 text-left text-text-heading transition hover:bg-tint-blue"
                  onMouseDown={() => {
                    setTitle(s);
                    setShowSuggestions(false);
                  }}
                >
                  {s}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {mode === "timer" && (
        <>
          <div className="my-10 flex flex-col items-center">
            <span className="font-heading text-6xl font-extrabold tabular-nums text-text-heading sm:text-7xl">
              {formatClock(elapsed)}
            </span>
            <span className="mt-2 text-sm font-medium uppercase tracking-wide text-text-body">
              {status === "idle" && "Ready when you are"}
              {status === "running" && "Reading in progress"}
              {status === "paused" && "Paused"}
            </span>
          </div>

          <div className="flex w-full flex-col gap-3">
            {status === "idle" && (
              <NavyButton fullWidth onClick={handleStart}>
                Start
              </NavyButton>
            )}
            {status === "running" && (
              <>
                <GoldButton fullWidth onClick={handlePause}>
                  Pause
                </GoldButton>
                <OutlineButton fullWidth onClick={handleStopAndSave}>
                  Stop &amp; Save
                </OutlineButton>
              </>
            )}
            {status === "paused" && (
              <>
                <NavyButton fullWidth onClick={handleResume}>
                  Resume
                </NavyButton>
                <GoldButton fullWidth onClick={handleStopAndSave}>
                  Stop &amp; Save
                </GoldButton>
              </>
            )}
          </div>

          {status === "idle" && (
            <button
              onClick={() => {
                setMode("manual");
                setValidationError(null);
              }}
              className="mt-6 text-sm font-medium text-text-body underline decoration-border-subtle underline-offset-4 transition hover:text-primary-navy"
            >
              Log a past session instead
            </button>
          )}
        </>
      )}

      {mode === "manual" && (
        <div className="mt-8 flex w-full flex-col gap-5">
          <div>
            <label htmlFor="manual-date" className="mb-1.5 block text-sm font-medium text-text-body">
              Date
            </label>
            <input
              id="manual-date"
              type="date"
              value={manualDate}
              max={todayDateString()}
              onChange={(e) => {
                setManualDate(e.target.value);
                setManualError(null);
              }}
              className="w-full rounded-[16px] border-2 border-border-subtle bg-bg-card px-4 py-3.5 font-heading text-lg font-semibold text-text-heading outline-none transition focus:border-primary-navy"
            />
          </div>

          <div>
            <label htmlFor="manual-minutes" className="mb-1.5 block text-sm font-medium text-text-body">
              Minutes read
            </label>
            <input
              id="manual-minutes"
              type="number"
              inputMode="numeric"
              min={1}
              step={1}
              value={manualMinutes}
              onChange={(e) => {
                setManualMinutes(e.target.value);
                setManualError(null);
              }}
              placeholder="e.g. 20"
              className="w-full rounded-[16px] border-2 border-border-subtle bg-bg-card px-4 py-3.5 font-heading text-lg font-semibold text-text-heading outline-none transition focus:border-primary-navy"
            />
          </div>

          {manualError && <p className="text-sm text-danger">{manualError}</p>}

          <NavyButton fullWidth onClick={handleSaveManual}>
            Save Session
          </NavyButton>

          <button
            onClick={() => {
              setMode("timer");
              setManualError(null);
            }}
            className="text-sm font-medium text-text-body underline decoration-border-subtle underline-offset-4 transition hover:text-primary-navy"
          >
            Use the live timer instead
          </button>
        </div>
      )}

      <ConfirmDialog
        open={pendingExit !== null}
        title="Discard this session?"
        message="You haven't saved this reading time yet. Leaving now will discard it — this can't be undone."
        confirmLabel="Discard"
        cancelLabel="Keep timing"
        destructive
        onConfirm={confirmExit}
        onCancel={cancelExit}
      />
    </div>
  );
}
