import { useEffect, useState, useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { getAllBooksWithStats, getWeeklyMinutes, getAllTimeMinutes } from "../db";
import type { BookWithStats } from "../types";
import { StatRing } from "../components/StatRing";
import { BookRow } from "../components/BookRow";
import { EmptyState } from "../components/EmptyState";
import { NavyButton, GoldButton } from "../components/Buttons";
import { Toast } from "../components/Toast";

export function Home() {
  const [books, setBooks] = useState<BookWithStats[]>([]);
  const [weeklyMinutes, setWeeklyMinutes] = useState(0);
  const [allTimeMinutes, setAllTimeMinutes] = useState(0);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  const load = useCallback(async () => {
    const [b, weekly, allTime] = await Promise.all([
      getAllBooksWithStats(),
      getWeeklyMinutes(),
      getAllTimeMinutes(),
    ]);
    setBooks(b);
    setWeeklyMinutes(weekly);
    setAllTimeMinutes(allTime);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const state = location.state as { toast?: string } | null;
    if (state?.toast) {
      setToast(state.toast);
      navigate(location.pathname, { replace: true, state: {} });
      const t = setTimeout(() => setToast(null), 3200);
      return () => clearTimeout(t);
    }
  }, [location, navigate]);

  if (loading) return null;

  return (
    <div className="mx-auto max-w-2xl px-5 pt-6 sm:pt-10">
      <h1 className="font-heading text-2xl font-extrabold text-text-heading sm:text-3xl">
        Your Reading
      </h1>
      <p className="mt-1 text-text-body">Track your time, one session at a time.</p>

      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <StatRing
          value={weeklyMinutes}
          maxValue={Math.max(weeklyMinutes, 150)}
          displayValue={String(weeklyMinutes)}
          label="This week"
          sublabel={`${weeklyMinutes} min read`}
          trackColor="#DBF3F0"
          arcColor="#2CA893"
        />
        <StatRing
          value={allTimeMinutes}
          maxValue={Math.max(allTimeMinutes, 300)}
          displayValue={String(allTimeMinutes)}
          label="All-time minutes"
          sublabel={`${books.length} ${books.length === 1 ? "book" : "books"} in progress`}
          trackColor="#FFF6DE"
          arcColor="#FCCA4A"
        />
      </div>

      <div className="mt-8">
        {books.length === 0 ? (
          <EmptyState
            title="Log your first reading session"
            subtitle="Hit start a session below and we'll track the time for you."
            action={
              <NavyButton onClick={() => navigate("/timer")}>Start a Session</NavyButton>
            }
          />
        ) : (
          <>
            <h2 className="mb-3 font-heading font-bold text-text-heading">Your books</h2>
            <div className="flex flex-col gap-3">
              {books.map((book) => (
                <BookRow key={book.id} book={book} />
              ))}
            </div>
          </>
        )}
      </div>

      {books.length > 0 && <div className="h-28 sm:h-8" />}

      {books.length > 0 && (
        <div className="fixed inset-x-0 bottom-16 z-30 flex justify-center gap-3 px-5 pb-3 sm:static sm:justify-start sm:pb-0">
          <div className="flex w-full max-w-2xl gap-3">
            <NavyButton fullWidth onClick={() => navigate("/timer")}>
              + Start a Session
            </NavyButton>
            <GoldButton fullWidth onClick={() => navigate("/sessions")}>
              View All Sessions
            </GoldButton>
          </div>
        </div>
      )}

      <Toast message={toast} />
    </div>
  );
}
