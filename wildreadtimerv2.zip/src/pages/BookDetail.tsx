import { useCallback, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getBookWithStats, getSessionsForBook, deleteSession } from "../db";
import type { BookWithStats, Session } from "../types";
import { formatDurationLong } from "../utils/format";
import { NavyButton } from "../components/Buttons";
import { SessionRow } from "../components/SessionRow";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { EmptyState } from "../components/EmptyState";

export function BookDetail() {
  const { bookId } = useParams<{ bookId: string }>();
  const navigate = useNavigate();
  const [book, setBook] = useState<BookWithStats | null>(null);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);
  const [sessionToDelete, setSessionToDelete] = useState<Session | null>(null);

  const load = useCallback(async () => {
    if (!bookId) return;
    const [b, s] = await Promise.all([getBookWithStats(bookId), getSessionsForBook(bookId)]);
    setBook(b);
    setSessions(s);
    setLoading(false);
  }, [bookId]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleConfirmDelete() {
    if (!sessionToDelete) return;
    await deleteSession(sessionToDelete.id);
    setSessionToDelete(null);

    if (sessions.length === 1) {
      navigate("/");
      return;
    }
    load();
  }

  if (loading) return null;

  if (!book) {
    return (
      <div className="mx-auto max-w-2xl px-5 pt-10">
        <EmptyState
          title="Book not found"
          subtitle="This book may have been deleted."
          action={<NavyButton onClick={() => navigate("/")}>Back to Library</NavyButton>}
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-5 pt-6 sm:pt-10">
      <button
        onClick={() => navigate("/")}
        className="mb-4 flex items-center gap-1.5 text-sm font-medium text-text-body transition hover:text-primary-navy"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M15 6l-6 6 6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        Library
      </button>

      <h1 className="font-heading text-2xl font-extrabold text-text-heading sm:text-3xl">
        {book.title}
      </h1>
      <p className="mt-1 text-text-body">
        {formatDurationLong(book.totalSeconds)} across {book.sessionCount}{" "}
        {book.sessionCount === 1 ? "session" : "sessions"}
      </p>

      <div className="mt-5">
        <NavyButton fullWidth onClick={() => navigate("/timer", { state: { bookTitle: book.title } })}>
          + Add to this book
        </NavyButton>
      </div>

      <div className="mt-8">
        <h2 className="mb-3 font-heading font-bold text-text-heading">Sessions</h2>
        {sessions.length === 0 ? (
          <EmptyState
            title="No sessions yet"
            subtitle="Hit Add to this book to begin."
          />
        ) : (
          <div className="flex flex-col gap-3">
            {sessions.map((session) => (
              <SessionRow
                key={session.id}
                session={session}
                onDelete={() => setSessionToDelete(session)}
              />
            ))}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={sessionToDelete !== null}
        title="Delete this session?"
        message="This can't be undone. The time will be subtracted from this book's total."
        confirmLabel="Delete"
        destructive
        onConfirm={handleConfirmDelete}
        onCancel={() => setSessionToDelete(null)}
      />
    </div>
  );
}
