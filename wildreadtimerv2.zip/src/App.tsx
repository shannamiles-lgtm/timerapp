import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { NavShell } from "./components/NavShell";
import { Home } from "./pages/Home";
import { Timer } from "./pages/Timer";
import { BookDetail } from "./pages/BookDetail";
import { AllSessions } from "./pages/AllSessions";

const router = createBrowserRouter([
  {
    path: "/",
    element: (
      <NavShell>
        <Home />
      </NavShell>
    ),
  },
  {
    path: "/timer",
    element: (
      <NavShell>
        <Timer />
      </NavShell>
    ),
  },
  {
    path: "/book/:bookId",
    element: (
      <NavShell>
        <BookDetail />
      </NavShell>
    ),
  },
  {
    path: "/sessions",
    element: (
      <NavShell>
        <AllSessions />
      </NavShell>
    ),
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
