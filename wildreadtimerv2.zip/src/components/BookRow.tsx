import { Link } from "react-router-dom";
import type { BookWithStats } from "../types";
import { formatDurationLong } from "../utils/format";

const tintPairs = [
  { bg: "bg-tint-blue", fg: "text-primary-navy" },
  { bg: "bg-tint-gold", fg: "text-[#9c7a10]" },
  { bg: "bg-tint-mint", fg: "text-[#1f7a6e]" },
];

function initialsFor(title: string): string {
  const words = title.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return "?";
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
  return (words[0][0] + words[1][0]).toUpperCase();
}

function tintForTitle(title: string) {
  let hash = 0;
  for (let i = 0; i < title.length; i++) hash = (hash + title.charCodeAt(i)) % tintPairs.length;
  return tintPairs[hash];
}

export function BookRow({ book }: { book: BookWithStats }) {
  const tint = tintForTitle(book.title);

  return (
    <Link
      to={`/book/${book.id}`}
      className="flex items-center gap-4 rounded-[20px] bg-bg-card p-4 shadow-[0_6px_18px_-12px_rgba(23,40,60,0.3)] transition hover:shadow-[0_10px_24px_-12px_rgba(23,40,60,0.35)] active:scale-[0.99]"
    >
      <div
        className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full font-heading font-bold ${tint.bg} ${tint.fg}`}
      >
        {initialsFor(book.title)}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate font-heading font-bold text-text-heading">{book.title}</p>
        <p className="truncate text-sm text-text-body">
          {formatDurationLong(book.totalSeconds)} across {book.sessionCount}{" "}
          {book.sessionCount === 1 ? "session" : "sessions"}
        </p>
      </div>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="shrink-0" aria-hidden="true">
        <path d="M9 6l6 6-6 6" stroke="#5D7184" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </Link>
  );
}
