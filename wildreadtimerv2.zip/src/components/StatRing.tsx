interface StatRingProps {
  value: number;
  maxValue: number;
  label: string;
  sublabel: string;
  trackColor: string;
  arcColor: string;
  displayValue: string;
}

export function StatRing({
  value,
  maxValue,
  label,
  sublabel,
  trackColor,
  arcColor,
  displayValue,
}: StatRingProps) {
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const progress = maxValue > 0 ? Math.min(value / maxValue, 1) : 0;
  const dashOffset = circumference * (1 - progress);

  return (
    <div className="flex items-center gap-4 rounded-[24px] bg-bg-card p-5 shadow-[0_10px_30px_-15px_rgba(23,40,60,0.25)]">
      <svg width="80" height="80" viewBox="0 0 80 80" className="shrink-0 -rotate-90">
        <circle cx="40" cy="40" r={radius} fill="none" stroke={trackColor} strokeWidth="10" />
        <circle
          cx="40"
          cy="40"
          r={radius}
          fill="none"
          stroke={arcColor}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          style={{ transition: "stroke-dashoffset 0.5s ease" }}
        />
        <text
          x="40"
          y="40"
          textAnchor="middle"
          dominantBaseline="central"
          transform="rotate(90 40 40)"
          className="fill-text-heading font-heading font-extrabold"
          fontSize="18"
        >
          {displayValue}
        </text>
      </svg>
      <div className="min-w-0">
        <p className="font-heading font-bold text-text-heading leading-tight">{label}</p>
        <p className="text-sm text-text-body">{sublabel}</p>
      </div>
    </div>
  );
}
