import type { ButtonHTMLAttributes, ReactNode } from "react";

interface BaseProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  icon?: ReactNode;
  fullWidth?: boolean;
}

export function NavyButton({
  children,
  icon,
  fullWidth,
  className = "",
  ...rest
}: BaseProps) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-[18px] bg-primary-navy px-6 py-4 font-heading font-semibold text-white shadow-[0_8px_20px_-8px_rgba(50,95,160,0.55)] transition active:scale-[0.98] hover:bg-primary-navy-dark disabled:opacity-50 disabled:pointer-events-none ${
        fullWidth ? "w-full" : ""
      } ${className}`}
      {...rest}
    >
      {icon}
      {children}
    </button>
  );
}

export function GoldButton({
  children,
  icon,
  fullWidth,
  className = "",
  ...rest
}: BaseProps) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-[18px] bg-accent-gold px-6 py-4 font-heading font-semibold text-text-heading shadow-[0_8px_20px_-8px_rgba(252,202,74,0.55)] transition active:scale-[0.98] hover:bg-accent-gold-dark disabled:opacity-50 disabled:pointer-events-none ${
        fullWidth ? "w-full" : ""
      } ${className}`}
      {...rest}
    >
      {icon}
      {children}
    </button>
  );
}

export function OutlineButton({
  children,
  icon,
  fullWidth,
  className = "",
  ...rest
}: BaseProps) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-[18px] border-2 border-border-subtle bg-white px-6 py-4 font-heading font-semibold text-text-heading transition active:scale-[0.98] hover:border-primary-navy disabled:opacity-50 disabled:pointer-events-none ${
        fullWidth ? "w-full" : ""
      } ${className}`}
      {...rest}
    >
      {icon}
      {children}
    </button>
  );
}
