interface ToastProps {
  message: string | null;
}

export function Toast({ message }: ToastProps) {
  if (!message) return null;

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-50 flex justify-center px-4 sm:bottom-8">
      <div className="pointer-events-auto max-w-sm rounded-[16px] bg-text-heading px-5 py-3 text-center text-sm font-medium text-white shadow-lg animate-[fade-in_0.15s_ease]">
        {message}
      </div>
    </div>
  );
}
