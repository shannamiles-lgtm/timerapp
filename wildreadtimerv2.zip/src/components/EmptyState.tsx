import type { ReactNode } from "react";

interface EmptyStateProps {
  title: string;
  subtitle: string;
  action?: ReactNode;
}

export function EmptyState({ title, subtitle, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center gap-4 rounded-[24px] bg-bg-card px-6 py-12 text-center shadow-[0_10px_30px_-15px_rgba(23,40,60,0.25)]">
      <svg width="88" height="88" viewBox="0 0 40 40" fill="none" aria-hidden="true">
        <rect width="40" height="40" rx="12" fill="#EBF4FB" />
        <path d="M9 13L15 18L11 22Z" fill="#FCCA4A" />
        <path d="M31 13L25 18L29 22Z" fill="#FCCA4A" />
        <circle cx="20" cy="23" r="10" fill="white" />
        <circle cx="16.5" cy="22" r="3.1" fill="#325FA0" />
        <circle cx="23.5" cy="22" r="3.1" fill="#325FA0" />
        <circle cx="16.5" cy="22" r="1.15" fill="white" />
        <circle cx="23.5" cy="22" r="1.15" fill="white" />
        <path d="M20 25.5L18.2 28.5H21.8L20 25.5Z" fill="#FCCA4A" />
      </svg>
      <div>
        <p className="font-heading text-lg font-bold text-text-heading">{title}</p>
        <p className="mt-1 text-sm text-text-body">{subtitle}</p>
      </div>
      {action}
    </div>
  );
}
