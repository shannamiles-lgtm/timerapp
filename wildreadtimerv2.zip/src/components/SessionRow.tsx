import type { Session } from "../types";
import { formatDateTime, formatSessionDuration } from "../utils/format";

interface SessionRowProps {
  session: Session;
  showBookTitle?: boolean;
  onDelete: () => void;
}

export function SessionRow({ session, showBookTitle, onDelete }: SessionRowProps) {
  return (
    <div className="flex items-center gap-3 rounded-[18px] bg-bg-card p-4 shadow-[0_6px_18px_-14px_rgba(23,40,60,0.3)]">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-tint-blue">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <circle cx="12" cy="13" r="8" stroke="#325FA0" strokeWidth="2" />
          <path d="M12 9v4l3 2" stroke="#325FA0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      <div className="min-w-0 flex-1">
        {showBookTitle && (
          <p className="truncate font-heading font-bold text-text-heading">{session.bookTitle}</p>
        )}
        <p className="truncate text-sm text-text-body">{formatDateTime(session.startedAt)}</p>
      </div>
      <span className="shrink-0 font-heading font-bold text-text-heading">
        {formatSessionDuration(session.durationSeconds)}
      </span>
      <button
        onClick={onDelete}
        aria-label="Delete session"
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-text-body transition hover:bg-tint-gold hover:text-danger"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path
            d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m2 0l-.7 12a2 2 0 0 1-2 1.9H9.7a2 2 0 0 1-2-1.9L7 7h10Z"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>
    </div>
  );
}
