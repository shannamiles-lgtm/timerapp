interface LogoProps {
  size?: number;
  withWordmark?: boolean;
}

export function Logo({ size = 40, withWordmark = false }: LogoProps) {
  return (
    <div className="flex items-center gap-2.5">
      <svg
        width={size}
        height={size}
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <rect width="40" height="40" rx="11" fill="#325FA0" />
        <path d="M8 12L14 17L10 21Z" fill="#FCCA4A" />
        <path d="M32 12L26 17L30 21Z" fill="#FCCA4A" />
        <circle cx="20" cy="22" r="10" fill="white" />
        <circle cx="16.5" cy="21" r="3.1" fill="#325FA0" />
        <circle cx="23.5" cy="21" r="3.1" fill="#325FA0" />
        <circle cx="16.5" cy="21" r="1.15" fill="white" />
        <circle cx="23.5" cy="21" r="1.15" fill="white" />
        <path d="M20 24.5L18.2 27.5H21.8L20 24.5Z" fill="#FCCA4A" />
      </svg>
      {withWordmark && (
        <span className="font-heading font-extrabold text-xl tracking-tight text-primary-navy">
          WildRead
          <span className="text-text-heading"> Timer</span>
        </span>
      )}
    </div>
  );
}
