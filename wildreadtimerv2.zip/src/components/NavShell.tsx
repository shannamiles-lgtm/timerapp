import { NavLink } from "react-router-dom";
import type { ReactNode } from "react";
import { Logo } from "./Logo";

interface NavItem {
  to: string;
  label: string;
  icon: (active: boolean) => ReactNode;
}

const HomeIcon = (active: boolean) => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path
      d="M4 11.5L12 4l8 7.5"
      stroke={active ? "white" : "#325FA0"}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M6 10v9a1 1 0 0 0 1 1h3v-5a2 2 0 1 1 4 0v5h3a1 1 0 0 0 1-1v-9"
      stroke={active ? "white" : "#325FA0"}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const TimerIcon = (active: boolean) => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <circle cx="12" cy="13" r="8" stroke={active ? "white" : "#325FA0"} strokeWidth="2" />
    <path d="M12 9v4l3 2" stroke={active ? "white" : "#325FA0"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M10 2h4M12 2v2" stroke={active ? "white" : "#325FA0"} strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const ListIcon = (active: boolean) => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M8 6h12M8 12h12M8 18h12" stroke={active ? "white" : "#325FA0"} strokeWidth="2" strokeLinecap="round" />
    <circle cx="4" cy="6" r="1.4" fill={active ? "white" : "#325FA0"} />
    <circle cx="4" cy="12" r="1.4" fill={active ? "white" : "#325FA0"} />
    <circle cx="4" cy="18" r="1.4" fill={active ? "white" : "#325FA0"} />
  </svg>
);

const navItems: NavItem[] = [
  { to: "/", label: "Library", icon: HomeIcon },
  { to: "/timer", label: "Timer", icon: TimerIcon },
  { to: "/sessions", label: "Sessions", icon: ListIcon },
];

export function NavShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh w-full bg-bg-page">
      <aside className="hidden w-64 shrink-0 flex-col gap-8 border-r border-border-subtle bg-bg-card p-6 sm:flex">
        <Logo size={40} withWordmark />
        <nav className="flex flex-col gap-1.5">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-[16px] px-4 py-3 font-medium transition ${
                  isActive
                    ? "bg-primary-navy text-white"
                    : "text-text-heading hover:bg-tint-blue"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  {item.icon(isActive)}
                  {item.label}
                </>
              )}
            </NavLink>
          ))}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between px-5 py-4 sm:hidden">
          <Logo size={32} withWordmark />
        </header>

        <main className="flex-1 overflow-y-auto pb-24 sm:pb-8">{children}</main>

        <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t border-border-subtle bg-bg-card px-2 py-2 sm:hidden">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className="flex flex-1 flex-col items-center gap-1 py-1.5"
            >
              {({ isActive }) => (
                <>
                  <span
                    className={`flex h-9 w-14 items-center justify-center rounded-full transition ${
                      isActive ? "bg-primary-navy" : ""
                    }`}
                  >
                    {item.icon(isActive)}
                  </span>
                  <span
                    className={`text-xs font-medium ${
                      isActive ? "text-primary-navy" : "text-text-body"
                    }`}
                  >
                    {item.label}
                  </span>
                </>
              )}
            </NavLink>
          ))}
        </nav>
      </div>
    </div>
  );
}
