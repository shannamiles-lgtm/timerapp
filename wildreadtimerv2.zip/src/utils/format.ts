export function formatClock(totalSeconds: number): string {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);
  const mm = String(minutes).padStart(2, "0");
  const ss = String(seconds).padStart(2, "0");
  if (hours > 0) {
    return `${hours}:${mm}:${ss}`;
  }
  return `${mm}:${ss}`;
}

/** e.g. 102 -> "1h 42m", 8 -> "8 min", 0 -> "0 min" */
export function formatMinutesLong(totalMinutes: number): string {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours === 0) return `${minutes} min`;
  if (minutes === 0) return `${hours}h`;
  return `${hours}h ${minutes}m`;
}

export function secondsToMinutes(seconds: number): number {
  return Math.round(seconds / 60);
}

export function formatSessionDuration(durationSeconds: number): string {
  const minutes = Math.round(durationSeconds / 60);
  if (minutes < 1) return "< 1 min";
  return `${minutes} min`;
}

/** Cumulative duration display that stays consistent with formatSessionDuration for sub-minute totals. */
export function formatDurationLong(totalSeconds: number): string {
  const totalMinutes = Math.round(totalSeconds / 60);
  if (totalSeconds > 0 && totalMinutes === 0) return "< 1 min";
  return formatMinutesLong(totalMinutes);
}

/** e.g. 82 -> "1 minute", 1 -> "1 minute", 0 -> "less than a minute" */
export function formatAddedDuration(durationSeconds: number): string {
  const minutes = Math.round(durationSeconds / 60);
  if (minutes < 1) return "less than a minute";
  if (minutes === 1) return "1 minute";
  return `${minutes} minutes`;
}

export function formatDateTime(iso: string): string {
  const date = new Date(iso);
  const today = new Date();
  const isToday = date.toDateString() === today.toDateString();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const isYesterday = date.toDateString() === yesterday.toDateString();

  const time = date.toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit",
  });

  if (isToday) return `Today, ${time}`;
  if (isYesterday) return `Yesterday, ${time}`;

  const dateStr = date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: date.getFullYear() === today.getFullYear() ? undefined : "numeric",
  });
  return `${dateStr}, ${time}`;
}
