import { openDB, type DBSchema, type IDBPDatabase } from "idb";
import { v4 as uuidv4 } from "uuid";
import type { Book, Session, BookWithStats } from "./types";

interface WildReadDB extends DBSchema {
  books: {
    key: string;
    value: Book;
    indexes: { "by-title-lower": string };
  };
  sessions: {
    key: string;
    value: Session;
    indexes: { "by-bookId": string; "by-startedAt": string };
  };
}

const DB_NAME = "wildread-timer";
const DB_VERSION = 1;

let dbPromise: Promise<IDBPDatabase<WildReadDB>> | null = null;

function getDB() {
  if (!dbPromise) {
    dbPromise = openDB<WildReadDB>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        const books = db.createObjectStore("books", { keyPath: "id" });
        books.createIndex("by-title-lower", "titleLower");

        const sessions = db.createObjectStore("sessions", { keyPath: "id" });
        sessions.createIndex("by-bookId", "bookId");
        sessions.createIndex("by-startedAt", "startedAt");
      },
    });
  }
  return dbPromise;
}

function normalizeTitle(title: string): string {
  return title.trim().toLowerCase();
}

export async function getAllBooksWithStats(): Promise<BookWithStats[]> {
  const db = await getDB();
  const [books, sessions] = await Promise.all([
    db.getAll("books"),
    db.getAll("sessions"),
  ]);

  const statsByBook = new Map<
    string,
    { totalSeconds: number; sessionCount: number; lastSessionAt: string | null }
  >();

  for (const session of sessions) {
    const existing = statsByBook.get(session.bookId) ?? {
      totalSeconds: 0,
      sessionCount: 0,
      lastSessionAt: null,
    };
    existing.totalSeconds += session.durationSeconds;
    existing.sessionCount += 1;
    if (!existing.lastSessionAt || session.startedAt > existing.lastSessionAt) {
      existing.lastSessionAt = session.startedAt;
    }
    statsByBook.set(session.bookId, existing);
  }

  return books
    .map((book) => {
      const stats = statsByBook.get(book.id) ?? {
        totalSeconds: 0,
        sessionCount: 0,
        lastSessionAt: null,
      };
      return { ...book, ...stats };
    })
    .filter((book) => book.sessionCount > 0)
    .sort((a, b) => {
      const aTime = a.lastSessionAt ?? a.createdAt;
      const bTime = b.lastSessionAt ?? b.createdAt;
      return bTime.localeCompare(aTime);
    });
}

export async function getBookWithStats(
  bookId: string,
): Promise<BookWithStats | null> {
  const db = await getDB();
  const book = await db.get("books", bookId);
  if (!book) return null;
  const sessions = await db.getAllFromIndex("sessions", "by-bookId", bookId);
  const totalSeconds = sessions.reduce((sum, s) => sum + s.durationSeconds, 0);
  const lastSessionAt = sessions.reduce<string | null>(
    (latest, s) => (!latest || s.startedAt > latest ? s.startedAt : latest),
    null,
  );
  return {
    ...book,
    totalSeconds,
    sessionCount: sessions.length,
    lastSessionAt,
  };
}

export async function getSessionsForBook(bookId: string): Promise<Session[]> {
  const db = await getDB();
  const sessions = await db.getAllFromIndex("sessions", "by-bookId", bookId);
  return sessions.sort((a, b) => b.startedAt.localeCompare(a.startedAt));
}

export async function getAllSessions(): Promise<Session[]> {
  const db = await getDB();
  const sessions = await db.getAll("sessions");
  return sessions.sort((a, b) => b.startedAt.localeCompare(a.startedAt));
}

export async function getAllBookTitles(): Promise<string[]> {
  const db = await getDB();
  const books = await db.getAll("books");
  return books.map((b) => b.title);
}

/** Finds an existing book by case-insensitive, trimmed title, or creates a new one. */
async function findOrCreateBook(
  db: IDBPDatabase<WildReadDB>,
  title: string,
): Promise<Book> {
  const trimmedTitle = title.trim();
  const titleLower = normalizeTitle(title);
  const existing = await db.getFromIndex("books", "by-title-lower", titleLower);
  if (existing) return existing;

  const book: Book & { titleLower: string } = {
    id: uuidv4(),
    title: trimmedTitle,
    createdAt: new Date().toISOString(),
    titleLower,
  };
  await db.put("books", book);
  return book;
}

export async function saveSession(params: {
  bookTitle: string;
  durationSeconds: number;
  startedAt: string;
  endedAt: string;
}): Promise<{ book: Book; session: Session }> {
  const db = await getDB();
  const book = await findOrCreateBook(db, params.bookTitle);

  const session: Session = {
    id: uuidv4(),
    bookId: book.id,
    bookTitle: book.title,
    durationSeconds: params.durationSeconds,
    startedAt: params.startedAt,
    endedAt: params.endedAt,
  };
  await db.put("sessions", session);

  return { book, session };
}

export async function deleteSession(sessionId: string): Promise<void> {
  const db = await getDB();
  const session = await db.get("sessions", sessionId);
  if (!session) return;

  await db.delete("sessions", sessionId);

  const remaining = await db.getAllFromIndex(
    "sessions",
    "by-bookId",
    session.bookId,
  );
  if (remaining.length === 0) {
    await db.delete("books", session.bookId);
  }
}

export async function getWeeklyMinutes(): Promise<number> {
  const db = await getDB();
  const sessions = await db.getAll("sessions");
  const now = Date.now();
  const weekAgo = now - 7 * 24 * 60 * 60 * 1000;
  const seconds = sessions
    .filter((s) => new Date(s.startedAt).getTime() >= weekAgo)
    .reduce((sum, s) => sum + s.durationSeconds, 0);
  return Math.round(seconds / 60);
}

export async function getAllTimeMinutes(): Promise<number> {
  const db = await getDB();
  const sessions = await db.getAll("sessions");
  const seconds = sessions.reduce((sum, s) => sum + s.durationSeconds, 0);
  return Math.round(seconds / 60);
}
