export interface Book {
  id: string;
  title: string;
  createdAt: string;
}

export interface Session {
  id: string;
  bookId: string;
  bookTitle: string;
  durationSeconds: number;
  startedAt: string;
  endedAt: string;
}

export interface BookWithStats extends Book {
  totalSeconds: number;
  sessionCount: number;
  lastSessionAt: string | null;
}
