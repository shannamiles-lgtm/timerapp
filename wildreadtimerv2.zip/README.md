# WildRead Timer

A single-purpose reading timer app: pick or type a book title, run a timer,
save the session, and view/edit your reading history. No accounts, no
backend — everything is stored locally in your browser via IndexedDB.

## Screens

- **Library** (`/`) — weekly/all-time stat rings and your book list
- **Timer** (`/timer`) — start/pause/resume/stop a reading session, with
  autocomplete against existing book titles
- **Book Detail** (`/book/:bookId`) — a book's cumulative total and its
  session history, with per-session delete
- **All Sessions** (`/sessions`) — a flat, reverse-chronological log of
  every session across all books

## Development

```bash
npm install
npm run dev      # start the dev server
npm run build    # type-check and produce a production build
npm run preview  # preview the production build locally
```

## Data & storage

Books and Sessions are persisted in the browser's IndexedDB (database
`wildread-timer`). There is no network call to store, sync, or back up
reading data — clearing site data or uninstalling removes it permanently.
