import { useCallback, useEffect, useState } from "react";
import { getAllSessions, deleteSession } from "../db";
import type { Session } from "../types";
import { SessionRow } from "../components/SessionRow";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { EmptyState } from "../components/EmptyState";
import { NavyButton } from "../components/Buttons";
import { useNavigate } from "react-router-dom";
import { sessionsToCsv, downloadCsv } from "../utils/csv";

export function AllSessions() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);
  const [sessionToDelete, setSessionToDelete] = useState<Session | null>(null);
  const navigate = useNavigate();

  const load = useCallback(async () => {
    const s = await getAllSessions();
    setSessions(s);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleConfirmDelete() {
    if (!sessionToDelete) return;
    await deleteSession(sessionToDelete.id);
    setSessionToDelete(null);
    load();
  }

  function handleExportCsv() {
    const csv = sessionsToCsv(sessions);
    const today = new Date().toISOString().slice(0, 10);
    downloadCsv(`wildread-reading-log-${today}.csv`, csv);
  }

  if (loading) return null;

  return (
    <div className="mx-auto max-w-2xl px-5 pt-6 sm:pt-10">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl font-extrabold text-text-heading sm:text-3xl">
            All Sessions
          </h1>
          <p className="mt-1 text-text-body">Every reading session, most recent first.</p>
        </div>
        {sessions.length > 0 && (
          <button
            onClick={handleExportCsv}
            className="shrink-0 rounded-[14px] border-2 border-border-subtle bg-white px-4 py-2.5 font-heading text-sm font-semibold text-text-heading transition hover:border-primary-navy"
          >
            Export CSV
          </button>
        )}
      </div>

      <div className="mt-6">
        {sessions.length === 0 ? (
          <EmptyState
            title="No sessions yet"
            subtitle="Hit Start a Session to begin."
            action={<NavyButton onClick={() => navigate("/timer")}>Start a Session</NavyButton>}
          />
        ) : (
          <div className="flex flex-col gap-3">
            {sessions.map((session) => (
              <SessionRow
                key={session.id}
                session={session}
                showBookTitle
                onDelete={() => setSessionToDelete(session)}
              />
            ))}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={sessionToDelete !== null}
        title="Delete this session?"
        message="This can't be undone. The time will be subtracted from that book's total."
        confirmLabel="Delete"
        destructive
        onConfirm={handleConfirmDelete}
        onCancel={() => setSessionToDelete(null)}
      />
    </div>
  );
}
