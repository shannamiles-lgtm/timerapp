import type { Session } from "../types";

function escapeCsvField(value: string): string {
  if (/[",\n]/.test(value)) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

export function sessionsToCsv(sessions: Session[]): string {
  const header = ["Book Title", "Date", "Duration (minutes)"];
  const rows = sessions.map((s) => [
    escapeCsvField(s.bookTitle),
    new Date(s.startedAt).toLocaleDateString(),
    String(Math.round(s.durationSeconds / 60)),
  ]);
  return [header, ...rows].map((row) => row.join(",")).join("\n");
}

export function downloadCsv(filename: string, csv: string) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
